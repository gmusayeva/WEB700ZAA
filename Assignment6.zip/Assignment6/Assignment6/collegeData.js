const Sequelize = require('sequelize');


const sequelize = new Sequelize('database', 'user', 'password', {
  host: 'host',
  dialect: 'postgres',
  port: 5432,
  dialectOptions: {
    ssl: { rejectUnauthorized: false }
  },
  query: { raw: true }
});

// Define the Student model
const Student = sequelize.define('Student', {
  studentNum: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  firstName: Sequelize.STRING,
  lastName: Sequelize.STRING,
  email: Sequelize.STRING,
  TA: Sequelize.BOOLEAN,
  course: Sequelize.STRING
});

// Define the Course model
const Course = sequelize.define('Course', {
  courseCode: {
    type: Sequelize.STRING,
    primaryKey: true
  },
  courseName: Sequelize.STRING
});

// Set up the hasMany relationship from Course to Student
Course.hasMany(Student, { foreignKey: 'course', sourceKey: 'courseCode' });
Student.belongsTo(Course, { foreignKey: 'course', targetKey: 'courseCode' });

// Exported functions
module.exports.initialize = function () {
  return sequelize.sync()
    .then(() => {
      console.log('Database & tables created!');
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to sync the database'));
    });
};

module.exports.getAllStudents = function () {
  return Student.findAll()
    .then(students => {
      if (students.length === 0) {
        return Promise.reject(new Error('query returned 0 results'));
      }
      return students;
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to fetch students'));
    });
};

module.exports.getTAs = function () {
  return Student.findAll({ where: { TA: true } })
    .then(students => {
      if (students.length === 0) {
        return Promise.reject(new Error('query returned 0 results'));
      }
      return students;
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to fetch TAs'));
    });
};

module.exports.getCourses = function () {
  return Course.findAll()
    .then(courses => {
      if (courses.length === 0) {
        return Promise.reject(new Error('query returned 0 results'));
      }
      return courses;
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to fetch courses'));
    });
};

module.exports.getStudentByNum = function (num) {
  return Student.findOne({ where: { studentNum: num } })
    .then(student => {
      if (!student) {
        return Promise.reject(new Error('query returned 0 results'));
      }
      return student;
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to fetch student'));
    });
};

module.exports.getStudentsByCourse = function (course) {
  return Student.findAll({ where: { course: course } })
    .then(students => {
      if (students.length === 0) {
        return Promise.reject(new Error('query returned 0 results'));
      }
      return students;
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to fetch students by course'));
    });
};

module.exports.addStudent = function (studentData) {
  return Student.create(studentData)
    .then(() => {
      return Promise.resolve();
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to add student'));
    });
};

module.exports.updateStudent = function (studentNum, studentData) {
  return Student.update(studentData, { where: { studentNum: studentNum } })
    .then((result) => {
      if (result[0] === 0) {
        return Promise.reject(new Error('No student updated'));
      }
      return Promise.resolve();
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to update student'));
    });
};

module.exports.deleteStudent = function (studentNum) {
  return Student.destroy({ where: { studentNum: studentNum } })
    .then((result) => {
      if (result === 0) {
        return Promise.reject(new Error('No student deleted'));
      }
      return Promise.resolve();
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to delete student'));
    });
};

module.exports.addCourse = function (courseData) {
  return Course.create(courseData)
    .then(() => {
      return Promise.resolve();
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to add course'));
    });
};

module.exports.getCourseByCode = function (courseCode) {
  return Course.findOne({ where: { courseCode: courseCode } })
    .then(course => {
      if (!course) {
        return Promise.reject(new Error('query returned 0 results'));
      }
      return course;
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to fetch course'));
    });
};

module.exports.updateCourse = function (courseCode, courseData) {
  return Course.update(courseData, { where: { courseCode: courseCode } })
    .then((result) => {
      if (result[0] === 0) {
        return Promise.reject(new Error('No course updated'));
      }
      return Promise.resolve();
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to update course'));
    });
};

module.exports.deleteCourse = function (courseCode) {
  return Course.destroy({ where: { courseCode: courseCode } })
    .then((result) => {
      if (result === 0) {
        return Promise.reject(new Error('No course deleted'));
      }
      return Promise.resolve();
    })
    .catch((err) => {
      return Promise.reject(new Error('Unable to delete course'));
    });
};
