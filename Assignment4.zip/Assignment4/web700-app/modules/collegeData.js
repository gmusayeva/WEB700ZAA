const fs = require('fs');
const path = require('path');

class Data {
    constructor(students, courses) {
        this.students = students;
        this.courses = courses;
    }
}

let dataCollection = null;

function initialize() {
    return new Promise((resolve, reject) => {
        fs.readFile(path.join(__dirname, '../data/students.json'), 'utf8', (err, studentsData) => {
            if (err) {
                reject('Unable to read students file');
                return;
            }

            fs.readFile(path.join(__dirname, '../data/courses.json'), 'utf8', (err, coursesData) => {
                if (err) {
                    reject('Unable to read courses file');
                    return;
                }

                const students = JSON.parse(studentsData);
                const courses = JSON.parse(coursesData);

                dataCollection = new Data(students, courses);
                resolve('Data successfully initialized');
            });
        });
    });
}

function getAllStudents() {
    return new Promise((resolve, reject) => {
        if (dataCollection && dataCollection.students) {
            if (dataCollection.students.length > 0) {
                resolve(dataCollection.students);
            } else {
                reject('No results returned');
            }
        } else {
            reject('No students data found');
        }
    });
}

function getTAs() {
    return new Promise((resolve, reject) => {
        if (dataCollection && dataCollection.students) {
            const TAs = dataCollection.students.filter(student => student.TA);
            if (TAs.length > 0) {
                resolve(TAs);
            } else {
                reject('No results returned');
            }
        } else {
            reject('No students data found');
        }
    });
}

function getCourses() {
    return new Promise((resolve, reject) => {
        if (dataCollection && dataCollection.courses) {
            if (dataCollection.courses.length > 0) {
                resolve(dataCollection.courses);
            } else {
                reject('No results returned');
            }
        } else {
            reject('No courses data found');
        }
    });
}

function getStudentsByCourse(course) {
    return new Promise((resolve, reject) => {
        if (dataCollection && dataCollection.students) {
            const studentsByCourse = dataCollection.students.filter(student => student.course === course);
            if (studentsByCourse.length > 0) {
                resolve(studentsByCourse);
            } else {
                reject('No results returned');
            }
        } else {
            reject('No students data found');
        }
    });
}

function getStudentByNum(num) {
    return new Promise((resolve, reject) => {
        if (dataCollection && dataCollection.students) {
            const student = dataCollection.students.find(student => student.studentNum === num);
            if (student) {
                resolve(student);
            } else {
                reject('No results returned');
            }
        } else {
            reject('No students data found');
        }
    });
}

// New function to add a student
function addStudent(studentData) {
    return new Promise((resolve, reject) => {
        if (dataCollection && dataCollection.students) {
            if (typeof studentData !== 'object' || studentData === null) {
                return reject(new Error('Invalid student data'));
            }

            // Set TA property if undefined
            studentData.TA = studentData.TA === undefined ? false : studentData.TA;
            
            // Set studentNum property
            studentData.studentNum = dataCollection.students.length + 261; // Adding 261 to start numbering from 261

            // Push the updated studentData object onto the students array
            dataCollection.students.push(studentData);
            
            // Resolve the promise with the added studentData
            resolve(studentData);
        } else {
            reject('No students data found');
        }
    });
}

// Export the functions, including the new addStudent function
module.exports = {
    initialize,
    getAllStudents,
    getTAs,
    getCourses,
    getStudentsByCourse,
    getStudentByNum,
    addStudent // Include addStudent in module.exports
};
